Etiquetas de <b><?php the_title() ?></b>:

<?php 
  //Lista de etiquetas
	
  the_tags('<ul class="list-inline"><li class="list-inline-item"><h3><span class="badge badge-info">','</span></h3></li><li class="list-inline-item"><h3><span class="badge badge-info">','</span></h3></li></ul>'); 
?>
