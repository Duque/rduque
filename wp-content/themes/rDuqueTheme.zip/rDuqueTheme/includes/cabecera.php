<div class="rd_cabecera">
	
		<a href="https://el-barbo.es/2016/12/12/entrevista-kike-calleja-rio-salvaje?origen=cabecera" title="Ir a Entrevista a Kike Calleja">
			<img src="<?php echo get_template_directory_uri() ?>/images/cabeceras/entrevista-kike-calleja.jpg" alt="Imagen no disponible de la Cabecera del sitio web http://El-Barbo.es">
		</a>

</div>



<?php 
	if ($post_slug != "publicitate-en-el-barbo-es") { 
		dynamic_sidebar('header'); 
	} 
?>