<nav itemscope itemtype="http://schema.org/ItemList">
	<?php 
		wp_nav_menu( array( 
			'theme_location' => 'aside',
			'menu_class' => 'list-group',
		) ); 
	?>

	<?php dynamic_sidebar('sidebar'); ?>

</nav>